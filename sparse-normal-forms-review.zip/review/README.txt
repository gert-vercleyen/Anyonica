Independent review of the supplied Anyonica sparse normal forms
20 November 2026

Verdict
The shipped Java code passed the independent Smith and row Hermite certificate
tests. Both public functions ran through J/Link under Wolfram 14.3 on Apple
silicon. A confirmed wrong result in factor transfer and several exceptions to
the claimed memory behavior merit changes before distribution.

Files and scope
SparseNormalForms.jar SHA-256
7d70f563265a2732ba4afe4e8c904298bf52967967a9538b3bada0f29da7f465
SparseNormalForms.m SHA-256
432ef9724543a780969e82ab323c966d0a21830fa0477838287bb4c4977a043d

The two files were copied to Kernel/ReductionTools/ in a temporary checkout of
https://github.com/gert-vercleyen/Anyonica at develop revision
2163836a6e085c833318332748b418a17a55708c (paclet 0.9.20.4). In a fresh
kernel, PacletDirectoryLoad on that checkout followed by Needs["Anyonica`"]
loaded the functions. The test confirmed anyonica.SparseNormalForms was loaded
by J/Link. No package or JVM configuration was needed in the user's session.
The overlay ZIP, Java sources, and tests mentioned in Claude's response were
absent from the supplied materials. This review used the compiled JAR.
The tests covered one Mathematica version and platform. Existing Anyonica
solver call sites in this checkout still invoke the Wolfram built-ins.

Findings

1. A failed J/Link factor setter can yield a wrong matrix (wrapper lines
   376-394). Set b = SparseArray[{{1, 2^32+1} -> 3}, {1, 2^32+1}]. With
   input {{1}}, either decomposition with "ApplyUTo" -> b emits a machine
   number overflow, then returns a first matrix with a single 1 at {1,1}.
   See results/full-paclet.log. The coordinate must fit a Java signed int.
   Check the success of input transfer, both setters, and the decomposition
   before reading the result. For a factor with oversized coordinates, either
   give a clear error or implement a path that preserves its exact positions.

2. A nonzero implicit background expands to a dense list during validation
   (lines 239-240). For example, SparseArray[{}, {m,n}, 1] is stored compactly,
   yet the wrapper calls Normal on it. A missing JAR raises a warning then calls
   SmithDecomposition or HermiteDecomposition on a dense list, computes all
   transforms, and drops the omitted ones (lines 480-503). The fallback test
   log covers full and omitted outputs. This automatic path is especially
   costly on the tall inputs that motivate the package.

3. ApplyUTo and ApplyVTo compute the full requested transformation before
   multiplying if the factor is all zero or has a coefficient with absolute
   value at least 2^31 (lines 280-286, 299-303, 340-342). On a tall matrix,
   even an m-by-1 zero factor can therefore incur the cost of the full U.

4. Factor mode can change the chosen unimodular transformations. For
   A = {{1},{1}} and B = {{1},{0}}, a default call gives U.B = {{1},{-1}}.
   The call with "ApplyUTo" -> B gives {{0},{1}} for both decompositions.
   Each can come from a valid U. A caller who needs a matched set of outputs
   should take them from the same run. Tiny.java reproduces this distinction.

5. The Hermite wrapper accepts "OmitTransformations" -> "Right" and returns
   the full result although its documented choices exclude "Right".

6. The Smith divisibility postpass is quadratic in the number of nonunit
   pivots on matrices such as 2 IdentityMatrix[n], which is already in normal
   form. The included Diagonal.java exercises this performance limitation.

Mathematical tests
CoreReview.java covered all 19,683 ternary 3-by-3 matrices and 6,000 seeded
rectangular, square, rank-deficient and arbitrary-precision cases. Every case
was tested with both algorithms. It checks both factorization identities,
determinants of magnitude one, Smith divisibility and positivity, and the row
Hermite pivot order, positivity, reduced entries and zero rows. 1,192 matrices
required arbitrary-precision input transfer. On 1,039 cases the suite also
checked omitted and applied transformations.

The public Wolfram functions passed all 106 ordinary inputs per decomposition,
including large integers and zero/rectangular matrices. Smith reference values
use the absolute values of the native Smith diagonal because the built-in can
preserve a negative sign, e.g. for {{-21}}. Hermite forms matched the native
HermiteDecomposition result exactly on all 106. The suite also checked 105
omission calls and 42 calls with supplied factors. The oversized factor is an
additional test with a documented incorrect result.

The full public calls on a 20,736-by-1,728 cyclic pentagon matrix took
0.71 seconds (Smith) and 1.49 seconds (Hermite) in one warmed local run,
including J/Link transfer, excluding input construction and verification.
Both factorization residuals were exactly zero. Smith with both transformations
omitted took 0.44 seconds. The independent Java check verified the Hermite
conditions and Smith invariants on the same example. On the 160,000-by-8,000
example, the Java Smith call without transforms took 11.49 seconds in one run
with a 768 MB JVM heap. It returned 7,619 ones followed by 20.

Reproducing the checks
In Wolfram, after loading the patched Anyonica package, evaluate
  Get["/absolute/path/to/review/CheckSparseNormalForms.wl"]
  Get["/absolute/path/to/review/PentagonWL.wl"]
The small-matrix failure association should be empty. The two wide-factor
outputs should have the same ArrayRules as the input factor. Compare the
supplied logs for the observed discrepancy in the original wrapper.

For the Java checks, the following commands use a Java 21 JDK on macOS or
Linux. Run them from the review directory with the original JAR available.
  JAR=/absolute/path/to/SparseNormalForms.jar
  mkdir -p classes
  javac -cp "$JAR" -d classes java/*.java
  java -Xmx512m -cp "classes:$JAR" CoreReview
  java -Xmx512m -cp "classes:$JAR" Tiny
  java -Xmx512m -cp "classes:$JAR" Diagonal
  java -Xmx512m -XX:ActiveProcessorCount=2 -cp "classes:$JAR" PentagonBench 12 S true check
  java -Xmx512m -XX:ActiveProcessorCount=2 -cp "classes:$JAR" PentagonBench 12 H true check
  java -Xmx768m -XX:ActiveProcessorCount=2 -cp "classes:$JAR" PentagonBench 20 S false
These Java timings cover the decomposition call itself.
