(* Evaluate Needs["Anyonica`"] with the two files installed before running this review.
   The final checks include a very wide matrix stored with a single nonzero.
   Always keep it sparse. *)
Begin["SparseNormalFormsReview`"];
Module[{cases, results = <||>, failures = <||>, record, sparse, a, s, h, sm, hm,
        u, d, v, uh, hh, missing, tagged, projected, got,
        left, right, m, n, input, col, b, wideResults, classLoaded},
  record[label_, ok_, sample_] := (
    AssociateTo[results, label -> (Lookup[results, label, 0] + 1)];
    If[!TrueQ[ok],
      AssociateTo[failures, label -> Append[Lookup[failures, label, {}], sample]]]
  );
  sparse[x_] := Head[x] === SparseArray;
  missing = Missing["NotComputed"];
  cases = BlockRandom[
    SeedRandom[20261120];
    Join[
      {{{0}}, {{-21}}, ConstantArray[0, {3, 5}], {{0, 7, 0}},
       {{1}, {1}}, {{0, 0}, {4, -6}, {-8, 12}},
       {{4, 6}, {2, 8}}, {{2^100, 2^64 + 1}, {-2^81, 2^90}},
       DiagonalMatrix[{6, 10, 15}], {{2^70, 0}, {0, 2^70}, {0, 0}}},
      Table[
        {m, n} = RandomInteger[{1, 7}, 2];
        RandomInteger[{-12, 12}, {m, n}] RandomChoice[{3, 2} -> {0, 1}, {m, n}],
        {96}]
    ]
  ];
  Do[
    a = cases[[i]];
    input = If[OddQ[i], SparseArray[a], a];
    (* Wolfram 14.3 can leave a negative unit multiple on the Smith diagonal. *)
    sm = Abs[SmithDecomposition[a][[2]]];
    hm = HermiteDecomposition[a][[2]];
    s = Check[Anyonica`SparseSmithDecomposition[input], $Failed];
    h = Check[Anyonica`SparseHermiteDecomposition[input], $Failed];
    record["Smith default", MatchQ[s, {_?sparse, _?sparse, _?sparse}] &&
      ({u, d, v} = Normal /@ s; d === sm && u.a.v === d &&
        Abs[Det[u]] === 1 && Abs[Det[v]] === 1), i];
    record["Hermite default", MatchQ[h, {_?sparse, _?sparse}] &&
      ({uh, hh} = Normal /@ h; hh === hm && uh.a === hh && Abs[Det[uh]] === 1), i];
    If[Mod[i, 5] === 0,
      Do[
        got = Anyonica`SparseSmithDecomposition[input, "OmitTransformations" -> omit];
        record["Smith omission", ListQ[got] && Normal[got[[2]]] === sm &&
          If[MemberQ[{"Left", All}, omit], got[[1]] === missing, sparse[got[[1]]]] &&
          If[MemberQ[{"Right", All}, omit], got[[3]] === missing, sparse[got[[3]]]], {i, omit}],
        {omit, {"Left", "Right", All}}];
      Do[
        got = Anyonica`SparseHermiteDecomposition[input, "OmitTransformations" -> omit];
        record["Hermite omission", ListQ[got] && got[[1]] === missing &&
          Normal[got[[2]]] === hm, {i, omit}], {omit, {"Left", All}}];
      (* Identity blocks certify the transformations used in this very call. *)
      {m, n} = Dimensions[a];
      left = Partition[Range[m], 1];
      right = {Range[n]};
      tagged = Join[IdentityMatrix[m], left, 2];
      projected = Join[IdentityMatrix[n], right];
      s = Anyonica`SparseSmithDecomposition[input, "ApplyUTo" -> tagged, "ApplyVTo" -> projected];
      h = Anyonica`SparseHermiteDecomposition[input, "ApplyUTo" -> tagged];
      record["Smith factor products", MatchQ[s, {_?sparse, _?sparse, _?sparse}] &&
        ({u, d, v} = Normal /@ s; u[[All, ;; m]].a.v[[;; n]] === d &&
        u[[All, ;; m]].left === u[[All, {m + 1}]] && right.v[[;; n]] === v[[{n + 1}]]), i];
      record["Hermite factor products", MatchQ[h, {_?sparse, _?sparse}] &&
        ({u, d} = Normal /@ h; u[[All, ;; m]].a === d &&
        u[[All, ;; m]].left === u[[All, {m + 1}]]), i]
    ],
    {i, Length[cases]}];
  classLoaded = AnyTrue[JLink`LoadedJavaClasses[],
    StringContainsQ[ToString[#, InputForm], "anyonica.SparseNormalForms"] &];
  Print["Wolfram ", $Version, ", Java class loaded = ", classLoaded];
  Print["Cases per check ", results];
  Print["Failures in the small-matrix tests ", failures];
  If[classLoaded,
    col = 2^32 + 1;
    b = SparseArray[{{1, col} -> 3}, {1, col}];
    wideResults = Table[
      got = fn[{{1}}, "ApplyUTo" -> b];
      If[MatchQ[got, {_SparseArray, __}],
        {Dimensions[First[got]], ArrayRules[First[got]]}, got],
      {fn, {Anyonica`SparseSmithDecomposition, Anyonica`SparseHermiteDecomposition}}];
    Print["Wide factor expected ", {Dimensions[b], ArrayRules[b]}];
    Print["Wide factor actual (Smith, Hermite) ", wideResults]
  ];
]
End[];
