import anyonica.SparseNormalForms;
import java.util.Arrays;

final class PentagonCertificate {
    static class CSR {
        int[] idx, cols, vals;
        CSR(int nrows, int size, int[] rs, int[] cs, int[] vs) {
            idx = new int[nrows + 1];
            for(int i=0; i<size; i++) idx[rs[i]]++;
            for(int i=1; i<idx.length; i++) idx[i] += idx[i-1];
            int[] place = idx.clone();
            cols = new int[size]; vals = new int[size];
            for(int i=0; i<size; i++) {
                int p = place[rs[i]-1]++;
                cols[p] = cs[i]-1; vals[p] = vs[i];
            }
        }
    }
    static CSR fetch(SparseNormalForms core, String which, int m) {
        if (!core.cooFitsInt(which)) throw new AssertionError("int array expected");
        return new CSR(m, core.cooLength(which), core.cooRows(which),core.cooCols(which),core.cooValues(which));
    }
    static void productAdd(long scalar, CSR mat, int row, long[] dest) {
        for (int k=mat.idx[row]; k<mat.idx[row+1]; k++)
            dest[mat.cols[k]] = Math.addExact(dest[mat.cols[k]], Math.multiplyExact(scalar, mat.vals[k]));
    }
    static void checkHnf(CSR h, int m, int n, int rk) {
        int[] pivotRows = new int[n], pivotVals = new int[n];
        Arrays.fill(pivotRows,-1);
        int last = -1;
        for(int r=0;r<m;r++) {
            int pc=n, pv=0;
            for(int j=h.idx[r];j<h.idx[r+1];j++) {
                if(h.vals[j]!=0 && h.cols[j]<pc) {pc=h.cols[j];pv=h.vals[j];}
            }
            if(r>=rk) {
                if(pc!=n) throw new AssertionError("nonzero bottom");
                continue;
            }
            if(pc<=last || pc==n || pv<=0) throw new AssertionError("pivots");
            last=pc; pivotRows[pc]=r; pivotVals[pc]=pv;
        }
        for(int r=0;r<rk;r++) for(int j=h.idx[r];j<h.idx[r+1];j++) {
            int c=h.cols[j];
            if(pivotRows[c]>r && (h.vals[j]<0 || h.vals[j]>=pivotVals[c])) throw new AssertionError("residue");
        }
        System.out.println("All row Hermite canonical conditions checked");
    }
    static void check(SparseNormalForms core, boolean smith, int m, int n, int nnz, int[] ri, int[] ci, int[] vi) {
        CSR a = new CSR(m,nnz,ri,ci,vi), u=fetch(core,"U",m), d=fetch(core,"D",m);
        if (!smith) checkHnf(d,m,n,core.getRank());
        CSR v=smith?fetch(core,"V",n):null;
        long[] ua = new long[n], uav = new long[n];
        for (int r=0; r<m; r++) {
            Arrays.fill(ua,0);
            for (int k=u.idx[r]; k<u.idx[r+1]; k++) productAdd(u.vals[k],a,u.cols[k],ua);
            long[] test = ua;
            if(smith) {
                Arrays.fill(uav,0);
                for(int j=0; j<n; j++) if(ua[j]!=0) productAdd(ua[j],v,j,uav);
                test = uav;
            }
            for(int k=d.idx[r]; k<d.idx[r+1]; k++) test[d.cols[k]]=Math.subtractExact(test[d.cols[k]], d.vals[k]);
            for(int j=0; j<n; j++) if(test[j]!=0) throw new AssertionError("identity at "+r+","+j);
        }
        System.out.println("Every entry of "+(smith?"U A V = D":"U A = H")+" checked exactly");
    }
}
