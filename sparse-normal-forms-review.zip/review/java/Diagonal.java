import anyonica.SparseNormalForms;
import java.util.Arrays;
class Diagonal {
    static long run(int n,int value) {
        int[] diagonal=new int[n], vals=new int[n];
        for(int i=0;i<n;i++) diagonal[i]=i+1;
        Arrays.fill(vals,value);
        SparseNormalForms s=new SparseNormalForms();
        s.setMatrix(n,n,diagonal,diagonal,vals);
        long t=System.nanoTime();
        s.smith(false,false);
        long elapsed=System.nanoTime()-t;
        if(!Arrays.equals(s.cooValues("D"),vals)) throw new AssertionError("wrong result");
        s.clear();
        return elapsed;
    }
    public static void main(String[] args) {
        for(int i=0;i<8;i++) run(200,2);
        for(int n:new int[]{2000,4000,8000,16000})
          for(int value=1;value<=2;value++) {
            long[] times=new long[3];
            for(int r=0;r<3;r++) times[r]=run(n,value);
            Arrays.sort(times);
            System.out.format("%d·I for n=%d, median Smith seconds %.4f%n",value,n,times[1]/1e9);
          }
    }
}
