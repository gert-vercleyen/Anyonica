import anyonica.SparseNormalForms;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

class PentagonBench {
    static int col(int x, int y, int z, int n) {
        return 1 + (x*n+y)*n + z;
    }

    public static void main(String[] args) {
        int n = Integer.parseInt(args[0]);
        boolean smith = args[1].equals("S");
        boolean factors = Boolean.parseBoolean(args[2]);
        int columns = n*n*n;
        int rows = n*columns;
        int[] ri = new int[5*rows], ci = new int[5*rows], vi = new int[5*rows];
        int row = 0, k = 0;
        for (int a=0; a<n; a++) for (int b=0; b<n; b++)
            for (int c=0; c<n; c++) for (int d=0; d<n; d++) {
                row++;
                Map<Integer,Integer> exponents = new TreeMap<>();
                exponents.merge(col(b,c,d,n),1,Integer::sum);
                exponents.merge(col((a+b)%n,c,d,n),-1,Integer::sum);
                exponents.merge(col(a,(b+c)%n,d,n),1,Integer::sum);
                exponents.merge(col(a,b,(c+d)%n,n),-1,Integer::sum);
                exponents.merge(col(a,b,c,n),1,Integer::sum);
                for (Map.Entry<Integer,Integer> e : exponents.entrySet()) {
                    if (e.getValue() != 0) {
                        ri[k] = row; ci[k] = e.getKey(); vi[k++] = e.getValue();
                    }
                }
            }
        SparseNormalForms core = new SparseNormalForms();
        core.setMatrix(rows,columns,Arrays.copyOf(ri,k),Arrays.copyOf(ci,k),Arrays.copyOf(vi,k));
        long start = System.nanoTime();
        if (smith) core.smith(factors,factors);
        else core.hermite(factors);
        double elapsed = (System.nanoTime()-start)/1e9;
        int[] rr = core.cooRows("D"), cc = core.cooCols("D"), vv = core.cooValues("D");
        int expected = columns - n*n + n;
        if (core.getRank() != expected) throw new AssertionError("rank");
        if (smith) {
            if (rr.length != expected) throw new AssertionError("Smith sparsity");
            for (int i=0; i<rr.length; i++) {
                if (rr[i] != cc[i] || rr[i] > expected || vv[i] != (rr[i]==expected?n:1)) {
                    throw new AssertionError("Smith form");
                }
            }
        }
        System.out.printf("N=%d shape=%dx%d nnz=%d %s factors=%s compute=%.3fs rank=%d formNNZ=%d",n,rows,columns,k,args[1],factors,elapsed,core.getRank(),rr.length);
        if (factors) {
            System.out.printf(" U-nnz=%d",core.cooLength("U"));
            if (smith) System.out.printf(" V-nnz=%d",core.cooLength("V"));
        }
        System.out.println();
        if (args.length > 3 && args[3].equals("check")) PentagonCertificate.check(core,smith,rows,columns,k,ri,ci,vi);
    }
}
