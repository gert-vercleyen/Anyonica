import anyonica.SparseNormalForms;
import java.util.Arrays;
class Tiny {
    public static void main(String[] args) {
        for(boolean smith:new boolean[]{true,false}) {
            for(boolean factor:new boolean[]{false,true}) {
                SparseNormalForms s = new SparseNormalForms();
                s.setMatrix(2,1,new int[]{1,2},new int[]{1,1},new int[]{1,1});
                if(factor) s.setLeftFactor(new int[]{1},new int[]{1},new int[]{1});
                if(smith) s.smith(true,true); else s.hermite(true);
                System.out.println(smith+" "+factor+" "+Arrays.deepToString(CoreReview.get(s,"U",2,factor?1:2)));
            }
        }
    }
}
