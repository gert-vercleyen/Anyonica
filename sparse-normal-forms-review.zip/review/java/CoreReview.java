import anyonica.SparseNormalForms;
import java.math.BigInteger;
import java.util.*;

public class CoreReview {
    static final BigInteger Z = BigInteger.ZERO, ONE = BigInteger.ONE;
    static final Random rng = new Random(0x5A173148L);
    static int cases, optionCases, bigInputs, mixedPrecisionCases, defaultSmithFactorDifferences, defaultHermiteFactorDifferences;
    static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
    }
    static BigInteger[][] zero(int m, int n) {
        BigInteger[][] a = new BigInteger[m][n];
        for (BigInteger[] row : a) Arrays.fill(row, Z);
        return a;
    }
    static BigInteger[][] product(BigInteger[][] a, BigInteger[][] b) {
        BigInteger[][] x = zero(a.length, b[0].length);
        for (int i=0; i<a.length; i++)
            for (int k=0; k<b.length; k++)
                if (a[i][k].signum()!=0)
                    for (int j=0; j<x[i].length; j++) x[i][j] = x[i][j].add(a[i][k].multiply(b[k][j]));
        return x;
    }
    static BigInteger det(BigInteger[][] matrix) {
        // Fraction-free elimination with row pivoting.
        int n=matrix.length;
        BigInteger[][] x=matrix.clone();
        for(int i=0; i<n; i++) x[i]=x[i].clone();
        int sign=1;
        BigInteger divisor=ONE;
        for(int k=0; k<n-1; k++) {
            int p=k;
            while(p<n && x[p][k].signum()==0) p++;
            if (p==n) return Z;
            if(p!=k) { BigInteger[] t=x[k]; x[k]=x[p]; x[p]=t; sign=-sign; }
            for(int i=k+1; i<n; i++) for(int j=k+1; j<n; j++)
                x[i][j]=x[i][j].multiply(x[k][k]).subtract(x[i][k].multiply(x[k][j])).divide(divisor);
            divisor=x[k][k];
        }
        return sign==1? x[n-1][n-1] : x[n-1][n-1].negate();
    }
    record COO(int[] r, int[] c, BigInteger[] v) {
        int[] intValues() {return Arrays.stream(v).mapToInt(BigInteger::intValueExact).toArray();}
    }
    static COO coo(BigInteger[][] a) {
        List<Integer> ri=new ArrayList<>(), ci=new ArrayList<>();
        List<BigInteger> vals=new ArrayList<>();
        for(int i=0; i<a.length; i++) for(int j=0; j<a[i].length; j++) {
            if(a[i][j].signum()==0) continue;
            ri.add(i+1); ci.add(j+1); vals.add(a[i][j]);
        }
        return new COO(ri.stream().mapToInt(Integer::intValue).toArray(), ci.stream().mapToInt(Integer::intValue).toArray(), vals.toArray(BigInteger[]::new));
    }
    static SparseNormalForms input(BigInteger[][] a) {
        COO e=coo(a);
        SparseNormalForms s=new SparseNormalForms();
        if(Arrays.stream(e.v).anyMatch(v->v.bitLength()>31)) {
            bigInputs++;
            s.setMatrixBig(a.length,a[0].length,e.r,e.c,String.join(" ",Arrays.stream(e.v).map(BigInteger::toString).toList()));
        } else {
            s.setMatrix(a.length,a[0].length,e.r,e.c,e.intValues());
        }
        return s;
    }
    static BigInteger[][] get(SparseNormalForms s,String field,int m,int n) {
        int[] ri=s.cooRows(field), ci=s.cooCols(field);
        BigInteger[] v;
        if(s.cooFitsInt(field)) v=Arrays.stream(s.cooValues(field)).mapToObj(BigInteger::valueOf).toArray(BigInteger[]::new);
        else {
            String t=s.cooValuesString(field);
            check(t.startsWith("{") && t.endsWith("}"),"big output serialization");
            v=t.length()==2?new BigInteger[0]:Arrays.stream(t.substring(1,t.length()-1).split(",")).map(BigInteger::new).toArray(BigInteger[]::new);
        }
        check(v.length==ri.length && v.length==ci.length && v.length==s.cooLength(field),"output lengths");
        BigInteger[][] x=zero(m,n);
        for(int i=0; i<v.length; i++) {
            check(x[ri[i]-1][ci[i]-1].signum()==0 && v[i].signum()!=0,"repeat coordinate or explicit zero");
            x[ri[i]-1][ci[i]-1]=v[i];
        }
        return x;
    }
    static int smithRank(BigInteger[][] d) {
        int rank=0;
        BigInteger last=ONE;
        for(int i=0; i<d.length; i++) for(int j=0; j<d[i].length; j++) {
            BigInteger v=d[i][j];
            if(v.signum()==0) continue;
            check(i==j && i==rank && v.signum()>0 && v.mod(last).signum()==0,"Smith canonical conditions");
            rank++; last=v;
        }
        return rank;
    }
    static int hermiteRank(BigInteger[][] h) {
        int rank=0, last=-1;
        for(int i=0; i<h.length; i++) {
            int j=0;
            while(j<h[i].length && h[i][j].signum()==0) j++;
            if(j==h[i].length) continue;
            check(i==rank && j>last && h[i][j].signum()>0,"Hermite pivot");
            for(int k=0;k<i;k++) check(h[k][j].signum()>=0 && h[k][j].compareTo(h[i][j])<0,"Hermite residue");
            rank++; last=j;
        }
        return rank;
    }
    static void same(BigInteger[][] a, BigInteger[][] b,String label) {
        if(!Arrays.deepEquals(a,b)) throw new AssertionError(label+" got "+Arrays.deepToString(a)+" expected "+Arrays.deepToString(b));
    }
    static void omitted(SparseNormalForms s,String which) {
        try { s.cooRows(which); } catch(IllegalStateException expected){return;}
        throw new AssertionError("unexpected materialized "+which);
    }
    static void test(BigInteger[][] a, boolean options) {
        try {
            int m=a.length, n=a[0].length;
            SparseNormalForms s=input(a);
            s.smith(true,true);
            BigInteger[][] d=get(s,"D",m,n), u=get(s,"U",m,m), v=get(s,"V",n,n);
            if(s.getUsedBigIntegers()) mixedPrecisionCases++;
            int rank=smithRank(d);
            check(rank==s.getRank(),"Smith rank");
            check(det(u).abs().equals(ONE) && det(v).abs().equals(ONE),"Smith unimodularity");
            same(product(product(u,a),v),d,"Smith identity");
            s.hermite(true);
            BigInteger[][] h=get(s,"D",m,n), w=get(s,"U",m,m);
            check(hermiteRank(h)==rank && s.getRank()==rank,"Hermite rank");
            check(det(w).abs().equals(ONE),"Hermite unimodularity");
            same(product(w,a),h,"Hermite identity");
            if(options) {
                for(int mask=0; mask<3; mask++) {
                    boolean left=(mask&1)!=0, right=(mask&2)!=0;
                    s.smith(left,right);
                    same(get(s,"D",m,n),d,"omitted Smith");
                    if(left) check(det(get(s,"U",m,m)).abs().equals(ONE),"omit/right U"); else omitted(s,"U");
                    if(right) check(det(get(s,"V",n,n)).abs().equals(ONE),"omit/left V"); else omitted(s,"V");
                }
                s.hermite(false);
                same(get(s,"D",m,n),h,"omitted Hermite"); omitted(s,"U");
                BigInteger[][] b=small(m,2,70), c=small(3,n,70);
                COO eb=coo(b), ec=coo(c);
                s.setLeftFactor(eb.r,eb.c,eb.intValues());
                s.setRightFactor(ec.r,ec.c,ec.intValues());
                s.smith(true,true);
                same(get(s,"D",m,n),d,"factored Smith");
                if (!Arrays.deepEquals(get(s,"U",m,2),product(u,b)) || !Arrays.deepEquals(get(s,"V",3,n),product(c,v))) defaultSmithFactorDifferences++;
                s.hermite(true);
                same(get(s,"D",m,n),h,"factored Hermite");
                if (!Arrays.deepEquals(get(s,"U",m,2),product(w,b))) defaultHermiteFactorDifferences++;

                // Include identity blocks to recover the very transformations chosen in this run.
                BigInteger[][] ib=zero(m,m+2), ci=zero(n+3,n);
                for(int i=0;i<m;i++) {
                    ib[i][i]=ONE;
                    System.arraycopy(b[i],0,ib[i],m,2);
                }
                for(int i=0;i<n;i++) ci[i][i]=ONE;
                for(int i=0;i<3;i++) ci[n+i]=c[i].clone();
                eb=coo(ib); ec=coo(ci);
                s.setLeftFactor(eb.r,eb.c,eb.intValues());
                s.setRightFactor(ec.r,ec.c,ec.intValues());
                s.smith(true,true);
                BigInteger[][] ub=get(s,"U",m,m+2), cv=get(s,"V",n+3,n);
                BigInteger[][] uf=zero(m,m), vf=Arrays.copyOfRange(cv,0,n);
                for(int i=0;i<m;i++) uf[i]=Arrays.copyOfRange(ub[i],0,m);
                check(det(uf).abs().equals(ONE) && det(vf).abs().equals(ONE),"factored Smith unimodularity");
                same(product(product(uf,a),vf),d,"factored Smith identity");
                same(product(uf,ib),ub,"same-run U.B"); same(product(ci,vf),cv,"same-run C.V");
                s.hermite(true);
                ub=get(s,"U",m,m+2);
                for(int i=0;i<m;i++) uf[i]=Arrays.copyOfRange(ub[i],0,m);
                check(det(uf).abs().equals(ONE),"factored HNF unimodularity");
                same(product(uf,a),h,"factored HNF identity");
                same(product(uf,ib),ub,"same-run HNF U.B");
                optionCases++;
            }
            s.clear(); cases++;
        } catch (Throwable ex) {
            System.err.println("case "+cases+" "+Arrays.deepToString(a));
            throw ex;
        }
    }
    static BigInteger[][] small(int m,int n,int density) {
        BigInteger[][] a=zero(m,n);
        for(int i=0; i<m; i++) for(int j=0; j<n; j++)
            if(rng.nextInt(100)<density) a[i][j]=BigInteger.valueOf(rng.nextInt(25)-12);
        return a;
    }
    public static void main(String[] args) {
        for(int code=0; code<19683; code++){
            int v=code;
            BigInteger[][] a=zero(3,3);
            for(int k=0;k<9;k++){a[k/3][k%3]=BigInteger.valueOf(v%3-1); v/=3;}
            test(a, code%127==0);
        }
        System.out.println("Exhaustive ternary 3x3 passed "+cases);
        for(int it=0; it<6000; it++) {
            int m=1+rng.nextInt(8), n=1+rng.nextInt(8);
            int density=rng.nextInt(101);
            BigInteger[][] a=small(m,n,density);
            if(it%7==0) { // exact rank factorization family, often deficient
                int inner=1+rng.nextInt(Math.min(m,n));
                a=product(small(m,inner,density),small(inner,n,density));
            }
            if(it%5==0) {
                for(int k=0;k<1+rng.nextInt(5);k++) {
                    int i=rng.nextInt(m), j=rng.nextInt(n);
                    int[] bits={31,32,60,61,62,63,64,65,93,127,193,257};
                    a[i][j]=ONE.shiftLeft(bits[rng.nextInt(bits.length)]).add(BigInteger.valueOf(rng.nextInt(5)-2));
                    if(rng.nextBoolean()) a[i][j]=a[i][j].negate();
                }
            }
            test(a, it%10==0 || it%19==0);
        }
        System.out.println("PASS "+cases+" total matrices; "+optionCases+" matrices with all omission/factor checks; "+bigInputs+" matrices through setMatrixBig; "+mixedPrecisionCases+" Smith getUsedBigIntegers; "+defaultSmithFactorDifferences+" Smith factors (left or right) and "+defaultHermiteFactorDifferences+" Hermite factors differed from default separate run; seed 0x5A173148.");
    }
}
