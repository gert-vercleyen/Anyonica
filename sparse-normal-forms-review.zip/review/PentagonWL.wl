(* Load the patched Anyonica paclet, then Get this file to check a cyclic pentagon matrix. *)
Begin["SparsePentagonReview`"];
Module[{size = 12, col, term, x, y, z, w, dims, row, a, s, h, want, t, u, d, v},
  dims = {size^4, size^3};
  row = Range[First[dims]];
  {x, y, z, w} = Transpose[Tuples[Range[0, size - 1], 4]];
  col[i_, j_, k_] := (i size + j) size + k + 1;
  term[c_] := SparseArray[Transpose[{row, c}] -> ConstantArray[1, Length[row]], dims];
  a = term[col[y,z,w]] - term[col[Mod[x+y,size],z,w]] + term[col[x,Mod[y+z,size],w]] -
    term[col[x,y,Mod[z+w,size]]] + term[col[x,y,z]];
  want = Join[ConstantArray[1,size^3-size^2+size-1],{size},
    ConstantArray[0, size^2-size]];
  (* Start Java before timing the public calls. *)
  Anyonica`SparseSmithDecomposition[{{2}}];
  {t,s} = AbsoluteTiming[Anyonica`SparseSmithDecomposition[a, "OmitTransformations"->All]];
  Print["N=12 Smith, omitted, seconds ", t, ", checks ", {s[[1]]===Missing["NotComputed"],
    s[[3]]===Missing["NotComputed"], Normal[Diagonal[s[[2]]]]===want}];
  {t,s} = AbsoluteTiming[Anyonica`SparseSmithDecomposition[a]];
  {u,d,v} = s;
  Print["N=12 Smith, full, seconds ",t,", factorization residual nonzero entries ",
    Count[(u.a.v - d)["NonzeroValues"], Except[0]], ", diagonal matches ", Normal[Diagonal[d]]===want];
  {t,h} = AbsoluteTiming[Anyonica`SparseHermiteDecomposition[a]];
  Print["N=12 Hermite, full, seconds ", t, ", factorization residual nonzero entries ",
    Count[(First[h].a - Last[h])["NonzeroValues"],Except[0]]];
]
End[];
